package it.exolab.netfilm.ejb.interfaces;

import javax.ejb.Local;

import it.exolab.netfilm.jpa.models.Categoria;

@Local
public interface CategoriaEjbInterface extends BaseInterface<Categoria> {
	
}
